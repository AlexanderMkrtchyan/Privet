"""Foreground window + idle on Linux (GNOME Wayland via AT-SPI + Mutter IdleMonitor)."""

from __future__ import annotations

from typing import Any


def get_idle_ms() -> int:
    try:
        import dbus

        bus = dbus.SessionBus()
        proxy = bus.get_object(
            "org.gnome.Mutter.IdleMonitor",
            "/org/gnome/Mutter/IdleMonitor/Core",
        )
        iface = dbus.Interface(proxy, "org.gnome.Mutter.IdleMonitor")
        return int(iface.GetIdletime())
    except Exception:
        return 0


def get_focus() -> dict[str, Any]:
    """Return {app, title} for the most likely focused window."""
    try:
        import gi

        gi.require_version("Atspi", "2.0")
        from gi.repository import Atspi

        Atspi.init()
        desktop = Atspi.get_desktop(0)
        candidates: list[dict[str, Any]] = []
        for i in range(desktop.get_child_count()):
            app = desktop.get_child_at_index(i)
            if not app:
                continue
            app_name = app.get_name() or ""
            for j in range(app.get_child_count()):
                win = app.get_child_at_index(j)
                if not win:
                    continue
                role = win.get_role_name() or ""
                if role not in ("frame", "window"):
                    continue
                st = win.get_state_set()
                if not st:
                    continue
                focused = st.contains(Atspi.StateType.FOCUSED)
                active = st.contains(Atspi.StateType.ACTIVE)
                if not (focused or active):
                    continue
                title = win.get_name() or ""
                candidates.append(
                    {
                        "app": app_name,
                        "title": title,
                        "role": role,
                        "focused": focused,
                        "active": active,
                        "shell": app_name.lower() in ("gnome-shell", "gdm-x-session", ""),
                    }
                )

        # Prefer focused non-shell frame; else active non-shell; else anything.
        for c in candidates:
            if c["focused"] and not c["shell"]:
                return {"app": c["app"], "title": c["title"]}
        for c in candidates:
            if c["active"] and not c["shell"]:
                return {"app": c["app"], "title": c["title"]}
        for c in candidates:
            if not c["shell"]:
                return {"app": c["app"], "title": c["title"]}
        if candidates:
            c = candidates[0]
            return {"app": c["app"], "title": c["title"]}
    except Exception:
        pass
    return {"app": "", "title": ""}
