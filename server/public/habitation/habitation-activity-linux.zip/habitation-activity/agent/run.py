#!/usr/bin/env python3
"""Habitation activity agent: capture → buffer → encrypt → upload."""

from __future__ import annotations

import argparse
import json
import os
import platform
import signal
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from common.api import ActivityApi  # noqa: E402
from common.config import default_data_dir, load_config, save_config  # noqa: E402
from common.crypto import encrypt  # noqa: E402


def now_local() -> datetime:
    return datetime.now().astimezone()


def day_key(dt: datetime | None = None) -> str:
    return (dt or now_local()).strftime("%Y-%m-%d")


def iso(dt: datetime) -> str:
    return dt.isoformat(timespec="seconds")


def detect_os() -> str:
    s = platform.system().lower()
    if s.startswith("win"):
        return "windows"
    if s == "darwin":
        return "macos"
    return "linux"


def capture_module(os_name: str):
    if os_name == "windows":
        from agent import windows_capture as cap
    else:
        from agent import linux_capture as cap
    return cap


class Agent:
    def __init__(self, config_path: Path | None = None):
        self.config_path = config_path
        self.cfg = load_config(config_path)
        if not self.cfg.get("passphrase") or not self.cfg.get("sync_token"):
            raise SystemExit("config needs passphrase and sync_token")
        if not self.cfg.get("device_id"):
            self.cfg["device_id"] = str(uuid.uuid4())
            save_config(self.cfg, config_path)
        self.os_name = self.cfg.get("os_name") or detect_os()
        self.cap = capture_module(self.os_name)
        self.data_dir = default_data_dir()
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.buf_path = self.data_dir / "buffer.jsonl"
        self.state_path = self.data_dir / "state.json"
        self.api = ActivityApi(self.cfg["api_base"], self.cfg["sync_token"])
        self.state = self._load_state()
        self.current: dict | None = None
        self._stop = False

    def _load_state(self) -> dict:
        if self.state_path.exists():
            try:
                return json.loads(self.state_path.read_text(encoding="utf-8"))
            except Exception:
                pass
        return {"seq_by_day": {}, "last_upload_at": 0}

    def _save_state(self) -> None:
        self.state_path.write_text(json.dumps(self.state, indent=2), encoding="utf-8")

    def _append_segment(self, seg: dict) -> None:
        with self.buf_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(seg, ensure_ascii=False) + "\n")

    def _close_current(self, end: datetime) -> None:
        if not self.current:
            return
        t0 = datetime.fromisoformat(self.current["t0"])
        if end <= t0:
            end = t0
        seg = {
            **self.current,
            "t1": iso(end),
            "os": self.os_name,
            "device_id": self.cfg["device_id"],
        }
        # drop tiny noise under 2s unless idle flip
        dur = (end - t0).total_seconds()
        if dur >= 2 or seg.get("idle"):
            self._append_segment(seg)
        self.current = None

    def _snapshot(self) -> tuple[str, str, bool]:
        idle_ms = self.cap.get_idle_ms()
        idle = idle_ms >= int(self.cfg.get("idle_seconds", 180)) * 1000
        if idle:
            return "idle", "", True
        focus = self.cap.get_focus()
        app = (focus.get("app") or "").strip()[:120]
        title = (focus.get("title") or "").strip()[:240]
        return app, title, False

    def tick(self) -> None:
        now = now_local()
        app, title, idle = self._snapshot()
        key = (app, title, idle)
        if self.current is None:
            self.current = {
                "t0": iso(now),
                "app": app,
                "title": title,
                "idle": idle,
            }
            return
        cur_key = (self.current["app"], self.current["title"], self.current["idle"])
        # also split at midnight
        if key != cur_key or day_key(datetime.fromisoformat(self.current["t0"])) != day_key(now):
            self._close_current(now)
            self.current = {
                "t0": iso(now),
                "app": app,
                "title": title,
                "idle": idle,
            }

    def upload_due(self, force: bool = False) -> int:
        now = time.time()
        every = int(self.cfg.get("upload_seconds", 180))
        if not force and now - float(self.state.get("last_upload_at") or 0) < every:
            return 0
        if not self.buf_path.exists():
            self.state["last_upload_at"] = now
            self._save_state()
            return 0

        lines = [ln for ln in self.buf_path.read_text(encoding="utf-8").splitlines() if ln.strip()]
        if not lines:
            self.state["last_upload_at"] = now
            self._save_state()
            return 0

        by_day: dict[str, list[dict]] = {}
        for ln in lines:
            seg = json.loads(ln)
            d = (seg.get("t0") or "")[:10] or day_key()
            by_day.setdefault(d, []).append(seg)

        uploaded = 0
        for day, segs in sorted(by_day.items()):
            seq_map = self.state.setdefault("seq_by_day", {})
            seq = int(seq_map.get(day, 0)) + 1
            payload = {
                "v": 1,
                "device_id": self.cfg["device_id"],
                "os": self.os_name,
                "day": day,
                "seq": seq,
                "uploaded_at": datetime.now(timezone.utc).isoformat(),
                "segments": segs,
            }
            blob = encrypt(self.cfg["passphrase"], json.dumps(payload, ensure_ascii=False))
            self.api.upload_chunk(
                device_id=self.cfg["device_id"],
                os_name=self.os_name,
                day=day,
                seq=seq,
                ciphertext=blob,
            )
            seq_map[day] = seq
            uploaded += 1

        # clear buffer after successful uploads
        self.buf_path.write_text("", encoding="utf-8")
        self.state["last_upload_at"] = now
        self._save_state()
        return uploaded

    def run(self) -> None:
        poll = float(self.cfg.get("poll_seconds", 5))
        print(
            f"[habitation-activity] os={self.os_name} device={self.cfg['device_id'][:8]}… "
            f"api={self.cfg['api_base']} poll={poll}s upload={self.cfg.get('upload_seconds')}s",
            flush=True,
        )

        def stop(*_args):
            self._stop = True

        signal.signal(signal.SIGINT, stop)
        signal.signal(signal.SIGTERM, stop)

        while not self._stop:
            try:
                self.tick()
                n = self.upload_due(force=False)
                if n:
                    print(f"[habitation-activity] uploaded {n} chunk(s)", flush=True)
            except Exception as e:
                print(f"[habitation-activity] error: {e}", flush=True)
            time.sleep(poll)

        # final flush
        try:
            self._close_current(now_local())
            n = self.upload_due(force=True)
            print(f"[habitation-activity] stopped, flushed {n} chunk(s)", flush=True)
        except Exception as e:
            print(f"[habitation-activity] flush error: {e}", flush=True)


def main() -> None:
    ap = argparse.ArgumentParser(description="Habitation OS activity agent")
    ap.add_argument("--config", type=Path, default=None)
    ap.add_argument("--once", action="store_true", help="one tick + forced upload, then exit")
    ap.add_argument("--upload", action="store_true", help="force upload buffer and exit")
    args = ap.parse_args()
    agent = Agent(args.config)
    if args.upload:
        agent._close_current(now_local())
        n = agent.upload_due(force=True)
        print(f"uploaded {n}")
        return
    if args.once:
        agent.tick()
        time.sleep(1)
        agent.tick()
        agent._close_current(now_local())
        n = agent.upload_due(force=True)
        print(f"once done, uploaded {n}")
        return
    agent.run()


if __name__ == "__main__":
    main()
