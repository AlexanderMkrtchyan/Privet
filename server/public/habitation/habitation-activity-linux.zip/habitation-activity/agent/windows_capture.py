"""Foreground window + idle on Windows via ctypes (no pywin32 required)."""

from __future__ import annotations

import ctypes
from ctypes import wintypes
from typing import Any


user32 = ctypes.windll.user32  # type: ignore[attr-defined]
kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]

GetForegroundWindow = user32.GetForegroundWindow
GetWindowTextW = user32.GetWindowTextW
GetWindowTextLengthW = user32.GetWindowTextLengthW
GetWindowThreadProcessId = user32.GetWindowThreadProcessId
OpenProcess = kernel32.OpenProcess
QueryFullProcessImageNameW = kernel32.QueryFullProcessImageNameW
CloseHandle = kernel32.CloseHandle
GetLastInputInfo = user32.GetLastInputInfo
GetTickCount = kernel32.GetTickCount

PROCESS_QUERY_LIMITED_INFORMATION = 0x1000


class LASTINPUTINFO(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.UINT), ("dwTime", wintypes.DWORD)]


def get_idle_ms() -> int:
    info = LASTINPUTINFO()
    info.cbSize = ctypes.sizeof(LASTINPUTINFO)
    if not GetLastInputInfo(ctypes.byref(info)):
        return 0
    return max(0, int(GetTickCount() - info.dwTime))


def _process_name(hwnd: int) -> str:
    pid = wintypes.DWORD()
    GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    if not pid.value:
        return ""
    handle = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not handle:
        return ""
    try:
        buf = ctypes.create_unicode_buffer(512)
        size = wintypes.DWORD(len(buf))
        if QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
            path = buf.value.replace("\\", "/")
            return path.rsplit("/", 1)[-1]
        return ""
    finally:
        CloseHandle(handle)


def get_focus() -> dict[str, Any]:
    hwnd = GetForegroundWindow()
    if not hwnd:
        return {"app": "", "title": ""}
    length = GetWindowTextLengthW(hwnd)
    title = ""
    if length > 0:
        buf = ctypes.create_unicode_buffer(length + 1)
        GetWindowTextW(hwnd, buf, length + 1)
        title = buf.value
    app = _process_name(hwnd)
    return {"app": app, "title": title}
