#!/usr/bin/env bash
# One-shot Linux setup: venv, config, systemd user service.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
CONF_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/habitation"
DATA_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/habitation-activity"
CONF="$CONF_DIR/activity.json"
UNIT_DIR="$HOME/.config/systemd/user"
UNIT="$UNIT_DIR/habitation-activity.service"

mkdir -p "$CONF_DIR" "$DATA_DIR" "$UNIT_DIR"
cd "$ROOT"
# system-site-packages: need distro gi/Atspi + dbus for window focus on GNOME Wayland
if [[ ! -d .venv ]]; then
  python3 -m venv --system-site-packages .venv
fi
.venv/bin/pip install -q -r requirements.txt

if [[ ! -f "$CONF" ]]; then
  cp "$ROOT/config.example.json" "$CONF"
  chmod 600 "$CONF"
  echo "Created $CONF — edit passphrase + sync_token, then re-run this script."
  exit 0
fi

cat > "$UNIT" <<EOF
[Unit]
Description=Habitation activity agent
After=graphical-session.target

[Service]
Type=simple
WorkingDirectory=$ROOT
ExecStart=$ROOT/.venv/bin/python $ROOT/agent/run.py --config $CONF
Restart=on-failure
RestartSec=5
Environment=DISPLAY=:0
Environment=WAYLAND_DISPLAY=wayland-0
Environment=XDG_RUNTIME_DIR=%t
Environment=DBUS_SESSION_BUS_ADDRESS=unix:path=%t/bus

[Install]
WantedBy=default.target
EOF

systemctl --user daemon-reload
systemctl --user enable --now habitation-activity.service
systemctl --user status habitation-activity.service --no-pager || true
echo
echo "Agent running. Report:"
echo "  $ROOT/.venv/bin/python $ROOT/viewer/report.py --config $CONF --days 14"
