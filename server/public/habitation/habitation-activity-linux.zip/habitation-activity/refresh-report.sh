#!/usr/bin/env bash
# Пересобрать свежий HTML-отчёт и открыть в браузере.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
CONF="${HABITATION_ACTIVITY_CONFIG:-$HOME/.config/habitation/activity.json}"
DAYS="${1:-1}"
"$ROOT/.venv/bin/python" "$ROOT/viewer/report.py" --config "$CONF" --days "$DAYS"
