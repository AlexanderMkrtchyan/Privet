# Habitation activity shared helpers
