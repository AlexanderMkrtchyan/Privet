"""HTTP client for encrypted activity chunks."""

from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from typing import Any


class ActivityApi:
    def __init__(self, api_base: str, sync_token: str):
        self.api_base = api_base.rstrip("/")
        self.sync_token = sync_token

    def _req(
        self,
        method: str,
        path: str,
        body: dict[str, Any] | None = None,
        query: dict[str, str] | None = None,
    ) -> Any:
        url = self.api_base + path
        if query:
            url += "?" + urllib.parse.urlencode(query)
        data = None
        headers = {
            "Authorization": f"Bearer {self.sync_token}",
            "Accept": "application/json",
            # Cloudflare browser-integrity rules reject the default Python-urllib UA.
            "User-Agent": "HabitationActivity/1.0 (Linux; personal) Mozilla/5.0",
        }
        if body is not None:
            data = json.dumps(body).encode("utf-8")
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                raw = resp.read().decode("utf-8")
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"HTTP {e.code} {path}: {detail}") from e

    def upload_chunk(
        self,
        *,
        device_id: str,
        os_name: str,
        day: str,
        seq: int,
        ciphertext: str,
    ) -> Any:
        return self._req(
            "POST",
            "/api/habitation/activity/chunks",
            {
                "device_id": device_id,
                "os": os_name,
                "day": day,
                "seq": seq,
                "ciphertext": ciphertext,
            },
        )

    def list_chunks(self, *, since_day: str | None = None, day: str | None = None) -> list[dict[str, Any]]:
        q: dict[str, str] = {}
        if since_day:
            q["since"] = since_day
        if day:
            q["day"] = day
        data = self._req("GET", "/api/habitation/activity/chunks", query=q or None)
        return list(data.get("chunks") or [])
