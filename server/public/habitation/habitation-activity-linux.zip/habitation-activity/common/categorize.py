"""Map app/title → coarse category for reports."""

from __future__ import annotations

import re

RULES: list[tuple[str, re.Pattern[str]]] = [
    ("adult", re.compile(r"(porn|xvideos|xhamster|xnxx|pornhub|onlyfans|chaturbate|spankbang|xxx|nhentai|hanime|rule34|erome|stripchat)", re.I)),
    ("youtube", re.compile(r"youtube|youtu\.be", re.I)),
    ("games", re.compile(r"(steam|epic games|dota|cs2|counter-strike|minecraft|roblox|chess\.com|lichess|minigames|game)", re.I)),
    ("social", re.compile(r"(instagram|tiktok|twitter|facebook|reddit|discord|telegram|vk\.|whatsapp)", re.I)),
    ("dev", re.compile(r"(cursor|code|vscode|pycharm|intellij|terminal|gnome-terminal|kitty|alacritty|github|gitlab|stackoverflow|android studio)", re.I)),
    ("work", re.compile(r"(obsidian|notion|docs\.google|libreoffice|word|excel|figma|kdenlive|davinci|premiere|blender|privet|banderdog|habitation)", re.I)),
    ("browser", re.compile(r"(chrome|firefox|brave|edge|chromium|safari)", re.I)),
    ("media", re.compile(r"(vlc|totem|spotify|rhythmbox|mpv|netflix|twitch)", re.I)),
]


def categorize(app: str, title: str) -> str:
    blob = f"{app or ''} {title or ''}"
    if not blob.strip():
        return "other"
    for name, rx in RULES:
        if rx.search(blob):
            return name
    return "other"


CATEGORY_COLORS = {
    "youtube": "#ef4444",
    "games": "#8b5cf6",
    "adult": "#be123c",
    "social": "#06b6d4",
    "dev": "#22c55e",
    "work": "#3b82f6",
    "browser": "#f59e0b",
    "media": "#ec4899",
    "idle": "#94a3b8",
    "other": "#64748b",
}

CATEGORY_LABELS_RU = {
    "youtube": "YouTube",
    "games": "Игры",
    "adult": "18+",
    "social": "Соцсети",
    "dev": "Код / IDE",
    "work": "Работа",
    "browser": "Браузер",
    "media": "Медиа",
    "idle": "AFK / idle",
    "other": "Другое",
}
