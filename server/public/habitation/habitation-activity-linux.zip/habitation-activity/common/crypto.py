"""E2E encryption for Habitation activity chunks.

Blob layout (base64 of):
  version (1 byte) = 1
  salt (16 bytes)
  nonce (12 bytes)
  ciphertext + GCM tag
"""

from __future__ import annotations

import base64
import os
from typing import Union

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

VERSION = 1
SALT_LEN = 16
NONCE_LEN = 12
ITERATIONS = 200_000
KEY_LEN = 32


def derive_key(passphrase: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=KEY_LEN,
        salt=salt,
        iterations=ITERATIONS,
    )
    return kdf.derive(passphrase.encode("utf-8"))


def encrypt(passphrase: str, plaintext: Union[str, bytes]) -> str:
    if isinstance(plaintext, str):
        plaintext = plaintext.encode("utf-8")
    salt = os.urandom(SALT_LEN)
    nonce = os.urandom(NONCE_LEN)
    key = derive_key(passphrase, salt)
    ct = AESGCM(key).encrypt(nonce, plaintext, None)
    blob = bytes([VERSION]) + salt + nonce + ct
    return base64.b64encode(blob).decode("ascii")


def decrypt(passphrase: str, blob_b64: str) -> bytes:
    raw = base64.b64decode(blob_b64)
    if not raw or raw[0] != VERSION:
        raise ValueError("unsupported activity blob version")
    salt = raw[1 : 1 + SALT_LEN]
    nonce = raw[1 + SALT_LEN : 1 + SALT_LEN + NONCE_LEN]
    ct = raw[1 + SALT_LEN + NONCE_LEN :]
    key = derive_key(passphrase, salt)
    return AESGCM(key).decrypt(nonce, ct, None)
