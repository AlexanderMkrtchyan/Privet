"""Load / save local activity agent config."""

from __future__ import annotations

import json
import os
import uuid
from pathlib import Path
from typing import Any

DEFAULT_API = "https://messenger.banderdog.com"


def default_config_path() -> Path:
    env = os.environ.get("HABITATION_ACTIVITY_CONFIG")
    if env:
        return Path(env).expanduser()
    return Path.home() / ".config" / "habitation" / "activity.json"


def default_data_dir() -> Path:
    env = os.environ.get("HABITATION_ACTIVITY_DATA")
    if env:
        return Path(env).expanduser()
    return Path.home() / ".local" / "share" / "habitation-activity"


def load_config(path: Path | None = None) -> dict[str, Any]:
    path = path or default_config_path()
    if not path.exists():
        raise FileNotFoundError(
            f"No config at {path}. Copy activity/config.example.json and fill passphrase + sync_token."
        )
    data = json.loads(path.read_text(encoding="utf-8"))
    data.setdefault("api_base", DEFAULT_API)
    data.setdefault("device_id", str(uuid.uuid4()))
    data.setdefault("idle_seconds", 180)
    data.setdefault("poll_seconds", 5)
    data.setdefault("upload_seconds", 180)
    data.setdefault("os_name", "")
    return data


def save_config(data: dict[str, Any], path: Path | None = None) -> Path:
    path = path or default_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return path
