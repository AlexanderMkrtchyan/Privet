# Habitation Activity

OS focus tracker (Linux + Windows) → encrypted upload → phone/desktop report.

## Secrets

- `sync_token` — auth to the server (same on every device)
- `passphrase` — E2E encryption key (server never sees plaintext)

Config: `~/.config/habitation/activity.json` (Linux) or `%USERPROFILE%\.habitation\activity.json` (Windows)

## Linux

```bash
cd activity
./setup_linux.sh   # first run creates config; edit token+passphrase; run again
.venv/bin/python viewer/report.py --days 14
```

## Windows

Open https://messenger.banderdog.com/habitation/ and follow the Russian steps.

## Server

Privet env: `HABITATION_ACTIVITY_TOKEN=...`

API:

- `POST /api/habitation/activity/chunks`
- `GET /api/habitation/activity/chunks?since=YYYY-MM-DD`
