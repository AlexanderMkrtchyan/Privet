#!/usr/bin/env python3
"""Sync encrypted activity from server, decrypt, show charts (GUI + HTML)."""

from __future__ import annotations

import argparse
import json
import sys
import webbrowser
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from common.api import ActivityApi  # noqa: E402
from common.categorize import CATEGORY_COLORS, CATEGORY_LABELS_RU, categorize  # noqa: E402
from common.config import default_data_dir, load_config  # noqa: E402
from common.crypto import decrypt  # noqa: E402


def parse_dt(s: str) -> datetime:
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


def fmt_seconds(sec: float) -> str:
    sec = int(max(0, sec))
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h}ч {m}м"
    if m:
        return f"{m}м"
    return f"{s}с"


def load_segments(cfg: dict, since_day: str | None, day: str | None) -> list[dict]:
    api = ActivityApi(cfg["api_base"], cfg["sync_token"])
    chunks = api.list_chunks(since_day=since_day, day=day)
    segs: list[dict] = []
    errors = 0
    for ch in chunks:
        try:
            raw = decrypt(cfg["passphrase"], ch["ciphertext"])
            payload = json.loads(raw.decode("utf-8"))
            for seg in payload.get("segments") or []:
                seg = dict(seg)
                seg["_os"] = payload.get("os") or seg.get("os") or ""
                seg["_device"] = payload.get("device_id") or seg.get("device_id") or ""
                segs.append(seg)
        except Exception:
            errors += 1
    segs.sort(key=lambda s: s.get("t0") or "")
    if errors:
        print(f"warning: failed to decrypt {errors} chunk(s)", file=sys.stderr)
    return segs


def aggregate(segs: list[dict]) -> dict:
    by_cat = Counter()
    by_app = Counter()
    by_day_cat: dict[str, Counter] = defaultdict(Counter)
    by_day_total = Counter()
    timeline = []
    for seg in segs:
        try:
            t0 = parse_dt(seg["t0"])
            t1 = parse_dt(seg["t1"])
        except Exception:
            continue
        dur = max(0.0, (t1 - t0).total_seconds())
        if dur <= 0:
            continue
        idle = bool(seg.get("idle"))
        app = seg.get("app") or ""
        title = seg.get("title") or ""
        cat = "idle" if idle else categorize(app, title)
        day = t0.astimezone().strftime("%Y-%m-%d")
        by_cat[cat] += dur
        by_day_cat[day][cat] += dur
        by_day_total[day] += dur
        if not idle:
            label = app or title or "—"
            by_app[label] += dur
        timeline.append(
            {
                "t0": t0.astimezone().isoformat(timespec="minutes"),
                "t1": t1.astimezone().isoformat(timespec="minutes"),
                "dur": dur,
                "cat": cat,
                "app": app,
                "title": title,
                "os": seg.get("_os") or seg.get("os") or "",
            }
        )
    return {
        "by_cat": by_cat,
        "by_app": by_app,
        "by_day_cat": by_day_cat,
        "by_day_total": by_day_total,
        "timeline": timeline,
    }


def write_html(agg: dict, out: Path, title: str) -> Path:
    cats = agg["by_cat"].most_common()
    days = sorted(agg["by_day_total"])
    apps = agg["by_app"].most_common(15)

    cat_labels = [CATEGORY_LABELS_RU.get(c, c) for c, _ in cats]
    cat_values = [round(v / 3600, 2) for _, v in cats]
    cat_colors = [CATEGORY_COLORS.get(c, "#64748b") for c, _ in cats]

    day_labels = days
    # stacked datasets per category present
    all_cats = sorted({c for d in days for c in agg["by_day_cat"][d]})
    datasets = []
    for c in all_cats:
        datasets.append(
            {
                "label": CATEGORY_LABELS_RU.get(c, c),
                "data": [round(agg["by_day_cat"][d].get(c, 0) / 3600, 2) for d in days],
                "backgroundColor": CATEGORY_COLORS.get(c, "#64748b"),
            }
        )

    app_labels = [a[:40] for a, _ in apps]
    app_values = [round(v / 3600, 2) for _, v in apps]

    rows = []
    for item in reversed(agg["timeline"][-80:]):
        rows.append(
            f"<tr><td>{item['t0'][11:16]}–{item['t1'][11:16]}</td>"
            f"<td>{CATEGORY_LABELS_RU.get(item['cat'], item['cat'])}</td>"
            f"<td>{fmt_seconds(item['dur'])}</td>"
            f"<td>{(item['app'] or '—')[:40]}</td>"
            f"<td>{(item['title'] or '')[:60]}</td>"
            f"<td>{item['os']}</td></tr>"
        )

    html = f"""<!DOCTYPE html>
<html lang="ru"><head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>{title}</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<style>
  :root {{ --bg:#0f1419; --card:#182029; --ink:#e8eef4; --muted:#8b9aab; --line:rgba(255,255,255,.08); }}
  * {{ box-sizing:border-box; }}
  body {{ margin:0; font-family: "Segoe UI", system-ui, sans-serif; background:
    radial-gradient(1200px 600px at 10% -10%, #1d3a55 0%, transparent 55%),
    radial-gradient(900px 500px at 100% 0%, #3a1d4a 0%, transparent 50%),
    var(--bg); color:var(--ink); }}
  main {{ max-width:1100px; margin:0 auto; padding:28px 18px 60px; }}
  h1 {{ font-size:28px; margin:0 0 6px; letter-spacing:-.02em; }}
  .sub {{ color:var(--muted); margin-bottom:22px; }}
  .grid {{ display:grid; grid-template-columns:1.1fr .9fr; gap:16px; }}
  @media (max-width:860px){{ .grid {{ grid-template-columns:1fr; }} }}
  .card {{ background:var(--card); border:1px solid var(--line); border-radius:18px; padding:16px 16px 10px; }}
  .card h2 {{ font-size:14px; text-transform:uppercase; letter-spacing:.08em; color:var(--muted); margin:0 0 10px; font-weight:600; }}
  canvas {{ width:100% !important; max-height:320px; }}
  table {{ width:100%; border-collapse:collapse; font-size:13px; }}
  th,td {{ text-align:left; padding:8px 6px; border-bottom:1px solid var(--line); vertical-align:top; }}
  th {{ color:var(--muted); font-weight:600; font-size:11px; text-transform:uppercase; letter-spacing:.06em; }}
  .kpis {{ display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin-bottom:16px; }}
  .kpi {{ background:var(--card); border:1px solid var(--line); border-radius:16px; padding:14px 16px; }}
  .kpi b {{ display:block; font-size:22px; margin-top:4px; }}
  .kpi span {{ color:var(--muted); font-size:12px; }}
</style></head><body>
<main>
  <h1>{title}</h1>
  <p class="sub">Расшифровано только у тебя. Сервер хранит ciphertext.</p>
  <div class="kpis">
    <div class="kpi"><span>Активное время</span><b>{fmt_seconds(sum(v for c,v in cats if c!='idle'))}</b></div>
    <div class="kpi"><span>AFK / idle</span><b>{fmt_seconds(agg['by_cat'].get('idle',0))}</b></div>
    <div class="kpi"><span>Дней в отчёте</span><b>{len(days)}</b></div>
  </div>
  <div class="grid">
    <div class="card"><h2>Категории (часы)</h2><canvas id="pie"></canvas></div>
    <div class="card"><h2>Топ приложений</h2><canvas id="apps"></canvas></div>
  </div>
  <div class="card" style="margin-top:16px"><h2>По дням (часы)</h2><canvas id="days"></canvas></div>
  <div class="card" style="margin-top:16px"><h2>Последние сегменты</h2>
    <table><thead><tr><th>Время</th><th>Категория</th><th>Длит.</th><th>App</th><th>Title</th><th>OS</th></tr></thead>
    <tbody>{''.join(rows) or '<tr><td colspan=6>Пока пусто — запусти агент.</td></tr>'}</tbody></table>
  </div>
</main>
<script>
const pie = new Chart(document.getElementById('pie'), {{
  type:'doughnut',
  data:{{ labels:{json.dumps(cat_labels, ensure_ascii=False)}, datasets:[{{ data:{json.dumps(cat_values)}, backgroundColor:{json.dumps(cat_colors)} }}] }},
  options:{{ plugins:{{ legend:{{ position:'bottom', labels:{{ color:'#c9d4df' }} }} }}, cutout:'58%' }}
}});
const apps = new Chart(document.getElementById('apps'), {{
  type:'bar',
  data:{{ labels:{json.dumps(app_labels, ensure_ascii=False)}, datasets:[{{ label:'часы', data:{json.dumps(app_values)}, backgroundColor:'#38bdf8' }}] }},
  options:{{ indexAxis:'y', plugins:{{ legend:{{ display:false }} }}, scales:{{ x:{{ ticks:{{ color:'#8b9aab' }}, grid:{{ color:'rgba(255,255,255,.06)' }} }}, y:{{ ticks:{{ color:'#c9d4df' }}, grid:{{ display:false }} }} }} }}
}});
const days = new Chart(document.getElementById('days'), {{
  type:'bar',
  data:{{ labels:{json.dumps(day_labels)}, datasets:{json.dumps(datasets, ensure_ascii=False)} }},
  options:{{ responsive:true, scales:{{ x:{{ stacked:true, ticks:{{ color:'#8b9aab' }}, grid:{{ display:false }} }}, y:{{ stacked:true, ticks:{{ color:'#8b9aab' }}, grid:{{ color:'rgba(255,255,255,.06)' }} }} }}, plugins:{{ legend:{{ position:'bottom', labels:{{ color:'#c9d4df' }} }} }} }}
}});
</script></body></html>"""
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html, encoding="utf-8")
    return out


def show_matplotlib(agg: dict, title: str) -> None:
    import matplotlib.pyplot as plt

    cats = agg["by_cat"].most_common()
    if not cats:
        print("No data yet.")
        return
    labels = [CATEGORY_LABELS_RU.get(c, c) for c, _ in cats]
    values = [v / 3600 for _, v in cats]
    colors = [CATEGORY_COLORS.get(c, "#64748b") for c, _ in cats]

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    fig.suptitle(title)
    axes[0].pie(values, labels=labels, colors=colors, autopct="%1.0f%%", startangle=90)
    axes[0].set_title("Категории")

    apps = agg["by_app"].most_common(10)
    if apps:
        axes[1].barh([a[:28] for a, _ in apps][::-1], [v / 3600 for _, v in apps][::-1], color="#38bdf8")
        axes[1].set_xlabel("часы")
        axes[1].set_title("Топ приложений")
    else:
        axes[1].text(0.5, 0.5, "нет активных сегментов", ha="center")
    plt.tight_layout()
    plt.show()


def main() -> None:
    ap = argparse.ArgumentParser(description="Habitation activity report")
    ap.add_argument("--config", type=Path, default=None)
    ap.add_argument("--days", type=int, default=14, help="how many days back to sync")
    ap.add_argument("--day", type=str, default=None, help="single day YYYY-MM-DD")
    ap.add_argument("--html-only", action="store_true")
    ap.add_argument("--gui", action="store_true", help="also open matplotlib window")
    ap.add_argument("--no-open", action="store_true")
    args = ap.parse_args()

    cfg = load_config(args.config)
    if args.day:
        since = None
        day = args.day
        title = f"Habitation · {day}"
    else:
        since = (datetime.now().astimezone() - timedelta(days=args.days)).strftime("%Y-%m-%d")
        day = None
        title = f"Habitation · последние {args.days} дн."

    print("Syncing…")
    segs = load_segments(cfg, since_day=since, day=day)
    print(f"segments: {len(segs)}")
    agg = aggregate(segs)
    out = default_data_dir() / "report.html"
    write_html(agg, out, title)
    print(f"HTML: {out}")
    if not args.no_open:
        webbrowser.open(out.as_uri())
    if args.gui and not args.html_only:
        show_matplotlib(agg, title)


if __name__ == "__main__":
    main()
