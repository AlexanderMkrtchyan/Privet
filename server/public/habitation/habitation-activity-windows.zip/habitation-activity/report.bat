@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "CONF=%USERPROFILE%\.habitation\activity.json"
".venv\Scripts\python.exe" "viewer\report.py" --config "%CONF%" --days 14
pause
