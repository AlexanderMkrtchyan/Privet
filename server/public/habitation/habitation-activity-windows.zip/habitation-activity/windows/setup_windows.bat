@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0.."

where python >nul 2>nul
if errorlevel 1 (
  echo.
  echo Python не найден. Установи с https://www.python.org/downloads/windows/
  echo и поставь галочку "Add python.exe to PATH".
  echo.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Создаю виртуальное окружение...
  python -m venv .venv
)

echo Ставлю зависимости...
".venv\Scripts\python.exe" -m pip install -q -r requirements.txt

set "CONF=%USERPROFILE%\.habitation\activity.json"
if not exist "%USERPROFILE%\.habitation" mkdir "%USERPROFILE%\.habitation"
if not exist "%CONF%" (
  copy /Y "config.example.json" "%CONF%" >nul
  echo.
  echo Создан файл настроек:
  echo   %CONF%
  echo Открой его в Блокноте, впиши sync_token и passphrase, сохрани.
  notepad "%CONF%"
  echo.
  echo После сохранения запусти setup_windows.bat ещё раз.
  pause
  exit /b 0
)

echo Останавливаю старый агент (если был)...
taskkill /F /IM python.exe /FI "WINDOWTITLE eq HabitationActivity*" >nul 2>nul

echo Создаю задачу автозапуска HabitationActivity...
schtasks /Create /F /TN "HabitationActivity" /SC ONLOGON /RL LIMITED ^
  /TR "\"%~dp0start_agent.bat\"" >nul

echo Запускаю агент сейчас...
start "HabitationActivity" "%~dp0start_agent.bat"

echo.
echo Готово. Агент работает.
echo Отчёт: report.bat
echo.
pause
