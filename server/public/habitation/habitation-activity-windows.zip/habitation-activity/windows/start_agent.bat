@echo off
chcp 65001 >nul
cd /d "%~dp0.."
title HabitationActivity
set "CONF=%USERPROFILE%\.habitation\activity.json"
"%cd%\.venv\Scripts\python.exe" "%cd%\agent\run.py" --config "%CONF%"
