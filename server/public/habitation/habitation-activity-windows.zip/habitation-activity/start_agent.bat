@echo off
chcp 65001 >nul
cd /d "%~dp0"
title HabitationActivity
set "CONF=%USERPROFILE%\.habitation\activity.json"
".venv\Scripts\python.exe" "agent\run.py" --config "%CONF%"
